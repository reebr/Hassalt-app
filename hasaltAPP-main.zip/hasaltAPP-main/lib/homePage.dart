import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:hassalt_app/items/myItems.dart';
 import 'auth/loginScreen.dart';
 
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
 bool isLoggedIn = false;

  @override
  void initState() {
    super.initState();
    checkAuthStatus();
  }

  void checkAuthStatus() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        isLoggedIn = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: Text(
            'Welcome to Hassalt!',
            style: TextStyle(fontSize: 24,color: Colors.green),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          isLoggedIn
              ? Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyItemsListPage()),
                )
              : Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                );
        },
        label: Text('Get Started'),
        icon: Icon(Icons.arrow_forward),
        backgroundColor: Colors.green, 
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
