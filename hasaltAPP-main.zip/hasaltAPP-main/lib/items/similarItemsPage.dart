import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hassalt_app/items/foundItemDetailPage.dart';
import 'package:hassalt_app/items/lostItemDetailPage.dart';

import '../shared/sharedDrawer.dart';

class SimilarItemsPage extends StatefulWidget {
  final String detectedClass;
  final String itemType;

  SimilarItemsPage({required this.detectedClass, required this.itemType});

  @override
  _SimilarItemsPageState createState() => _SimilarItemsPageState();
}

class _SimilarItemsPageState extends State<SimilarItemsPage> {
  @override
  Widget build(BuildContext context) {
    CollectionReference<Map<String, dynamic>> collectionRef;
    if (widget.itemType == 'found') {
      collectionRef = FirebaseFirestore.instance.collection('lost');
    } else {
      collectionRef = FirebaseFirestore.instance.collection('found');
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Similar ${widget.detectedClass} Items'),        backgroundColor: Colors.green,

      ),
            drawer: SharedDrawer(),

      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: collectionRef
            .where('detectedClass', isEqualTo: widget.detectedClass)
            .snapshots(),
        builder: (BuildContext context,
            AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot) {
          if (snapshot.hasError) {
            return Text('Something went wrong');
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          }

          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (BuildContext context, int index) {
              var doc = snapshot.data!.docs[index];
              return ListTile(
                title: Text(doc['detectedClass']),
                subtitle: Text(doc['description']),
                leading: Image.network(doc['image']),
                onTap: () {
                  if (widget.itemType == 'found') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            LostItemDetailPage(lostItemId: doc.id),
                      ),
                    );
                  } else {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            FoundItemDetailPage(foundItemId: doc.id),
                      ),
                    );
                  }
                },
              );
            },
          );
        },
      ),
    );
  }
}
