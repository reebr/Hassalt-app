import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hassalt_app/shared/sharedDrawer.dart';

import 'foundItemDetailPage.dart';
import 'lostItemDetailPage.dart';

class MyItemsListPage extends StatefulWidget {
  @override
  _MyItemsListPageState createState() => _MyItemsListPageState();
}

class _MyItemsListPageState extends State<MyItemsListPage> {
  FilterOption _filterOption = FilterOption.lost;
  final _currentUserId = FirebaseAuth.instance.currentUser!.uid;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Items List'),        backgroundColor: Colors.green,

      ),
      drawer: SharedDrawer(),
      body: Column(
        children: [
          _buildFilterRadioButtons(),
          Expanded(child: _buildItemList()),
        ],
      ),
    );
  }

  Widget _buildFilterRadioButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('Lost'),
        Radio<FilterOption>(
          activeColor: Colors.green,
          value: FilterOption.lost,
          groupValue: _filterOption,
          onChanged: (FilterOption? value) {
            setState(() {
              _filterOption = value!;
            });
          },
        ),
        Text('Found'),
        Radio<FilterOption>(
          activeColor: Colors.green,
          value: FilterOption.found,
          groupValue: _filterOption,
          onChanged: (FilterOption? value) {
            setState(() {
              _filterOption = value!;
            });
          },
        ),
      ],
    );
  }

  Widget _buildItemList() {
    CollectionReference<Map<String, dynamic>> collectionRef;
    String dateKey;

    if (_filterOption == FilterOption.lost) {
      collectionRef = FirebaseFirestore.instance.collection('lost');
      dateKey = 'dateLost';
    } else {
      collectionRef = FirebaseFirestore.instance.collection('found');
      dateKey = 'dateFound';
    }

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: collectionRef.where('user', isEqualTo: _currentUserId).snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot) {
        if (snapshot.hasError) {
          return Text('Something went wrong');
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator();
        }

        return ListView.builder(
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (BuildContext context, int index) {
            var doc = snapshot.data!.docs[index];
            return ListTile(
              title: Text(doc['detectedClass']),
              subtitle: Text(doc['description']),
              leading: Image.network(doc['image']),
              onTap: () {
                if (_filterOption == FilterOption.lost) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => LostItemDetailPage(lostItemId: doc.id),
                    ),
                  );
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FoundItemDetailPage(foundItemId: doc.id),
                    ),
                  );
                }
              },
              trailing: IconButton(
                icon: Icon(Icons.delete),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Delete Item'),
                        content: Text('Are you sure you want to delete this item?'),
                        actions: [
                          TextButton(
                            child: Text('Cancel'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          TextButton(child: Text('Delete'),
onPressed: () async {
await collectionRef.doc(doc.id).delete();
Navigator.of(context).pop();
},
),
],
);
},
);
},
),
);
},
);
},
);
}
}

enum FilterOption { lost, found }


                           
