import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

import '../shared/sharedDrawer.dart';
import 'foundItemDetailPage.dart';

class FoundItemsPage extends StatefulWidget {
  @override
  _FoundItemsPageState createState() => _FoundItemsPageState();
}

class _FoundItemsPageState extends State<FoundItemsPage> {
  late CollectionReference<Map<String, dynamic>> _foundItemsCollection;
  late Stream<QuerySnapshot<Map<String, dynamic>>> _foundItemsStream;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String _selectedClass = 'All';
  TextEditingController _searchController = TextEditingController();
  List<String> _detectedClasses = [];
    bool _isAdmin = false;

  @override
  void initState() {
    super.initState();
    _foundItemsCollection = FirebaseFirestore.instance.collection('found');
    _foundItemsStream = _foundItemsCollection.snapshots();
    _getDetectedClasses();
        _checkIfUserIsAdmin();
  }

  Future<void> _signOut() async {
    await _auth.signOut();
    Navigator.pop(context);
  }
  
   Future<void> _checkIfUserIsAdmin() async {
    final currentUser = _auth.currentUser;
    if (currentUser != null) {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      setState(() {
        _isAdmin = userDoc.data()?['isAdmin'] ?? false;
      });
    }
  }
  Future<void> _getDetectedClasses() async {
    QuerySnapshot<Map<String, dynamic>> snapshot =
        await _foundItemsCollection.get();
    List<String> detectedClasses = [];
    for (var doc in snapshot.docs) {
      String detectedClass = doc.data()['detectedClass'];
      if (!detectedClasses.contains(detectedClass)) {
        detectedClasses.add(detectedClass);
      }
    }
    setState(() {
      _detectedClasses = detectedClasses;
    });
  }

  void _filter() {
    setState(() {
      _foundItemsStream = _foundItemsCollection
          .where('detectedClass',
              isEqualTo: _selectedClass == 'All' ? null : _selectedClass)
          .snapshots();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // For FoundItemsPage

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
  child: Row(
    children: [
      Expanded(
        child: TextField(
          controller: _searchController,
          decoration: InputDecoration(
            hintText: 'Search by description',
            contentPadding:
                EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.0),
            ),
          ),
          onChanged: (value) {
            _filter();
          },
        ),
      ),
      SizedBox(width: 8.0),
      DropdownButton<String>(
        value: _selectedClass,
        onChanged: (String? newValue) {
          if (newValue != null) {
            setState(() {
              _selectedClass = newValue;
            });
            _filter();
          }
        },
        items: ['All', ..._detectedClasses]
            .map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
        underline: Container(
          height: 2,
          color: Theme.of(context).primaryColor,
        ),
      ),
    ],
  ),
),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: _foundItemsStream,
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text('Error: ${snapshot.error}'),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
                if (snapshot.data == null) {
                  return Center(
                    child: Text('No found items found.'),
                  );
                }
                List<DocumentSnapshot<Map<String, dynamic>>> foundItems =
                    snapshot.data!.docs;
                if (foundItems.isEmpty) {
                  return Center(
                    child: Text('No found items found.'),
                  );
                } // Filter the items based on the search text.
                foundItems = foundItems.where((item) {
                  final description =
                      item.data()!['description'].toString().toLowerCase();
                  final searchText = _searchController.text.toLowerCase();
                  return description.contains(searchText);
                }).toList();

                return ListView.builder(
                  itemCount: foundItems.length,
                  itemBuilder: (context, index) {
                    final foundItem = foundItems[index].data();
                    final image = foundItem!['image'];
                    final description = foundItem['description'];
                    final detectedClass = foundItem['detectedClass'];
                    final dateFound = foundItem['dateFound'] as Timestamp;
                    final formattedDate = DateFormat('yyyy-MM-dd HH:mm')
                        .format(dateFound.toDate());

                  return ListTile(
                  leading: Image.network(
                    image,
                    height: 100,
                    width: 100,
                    fit: BoxFit.cover,
                  ),
                  title: Text(description),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Detected Class: $detectedClass'),
                      Text('Date Found: $formattedDate'),
                    ],
                  ),
                  trailing: Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 8.0,
                    children: [
                      TextButton(
                        onPressed: () => {
                          _viewFoundItem(foundItems[index].id),
                        },
                        child: const Text('View'),
                      ),
                      if (_isAdmin)
                        IconButton(
                          onPressed: () =>
                              {_deleteFoundItem(foundItems[index].id)},
                          icon: Icon(Icons.delete),
                        ),
                    ],
                  ),
                );


                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _viewFoundItem(String foundItemId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FoundItemDetailPage(foundItemId: foundItemId),
      ),
    );
  }

   Future<void> _deleteFoundItem(String foundItemId) async {
      await _foundItemsCollection.doc(foundItemId).delete();
      }
}
