// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:hassalt_app/items/similarItemsPage.dart';
// import 'package:hassalt_app/shared/sharedDrawer.dart';
//  import 'package:intl/intl.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:permission_handler/permission_handler.dart';

// import '../chat/chatPage.dart';

// class LostItemDetailPage extends StatefulWidget {
//   final String lostItemId;

//   LostItemDetailPage({ required this.lostItemId});

//   @override
//   _LostItemDetailPageState createState() => _LostItemDetailPageState();
// }

// class _LostItemDetailPageState extends State<LostItemDetailPage> {
//   late DocumentReference<Map<String, dynamic>> _LostItemDocument;
//   late Future<DocumentSnapshot<Map<String, dynamic>>> _LostItemFuture;

// @override
// void initState() {
//   super.initState();
//   _requestLocationPermission();
//   _LostItemDocument =
//       FirebaseFirestore.instance.collection('lost').doc(widget.lostItemId);
//   _LostItemFuture = _LostItemDocument.get();
// }

//   Future<DocumentSnapshot<Map<String, dynamic>>> _getUserDocument(String userId) async {
//     return await FirebaseFirestore.instance.collection('users').doc(userId).get();
//   }

//   Future<void> _requestLocationPermission() async {
//   PermissionStatus status = await Permission.locationWhenInUse.request();
//   if (status.isDenied) {
//   }
// }

//   @override
//   Widget build(BuildContext context) {
//           final loggedInUser = FirebaseAuth.instance.currentUser!;

//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Lost Item Details'),
//       ),
//       drawer: SharedDrawer(),
//       body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
//         future: _LostItemFuture,
//         builder: (context, snapshot) {
//           if (snapshot.hasError) {
//             return Center(
//               child: Text('Error: ${snapshot.error}'),
//             );
//           }
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return Center(
//               child: CircularProgressIndicator(),
//             );
//           }
//           if (snapshot.data == null) {
//             return Center(
//               child: Text('No Lost item found.'),
//             );
//           }
//           final LostItem = snapshot.data!.data();
//           final image = LostItem!['image'];
//           final description = LostItem['description'];
//           final detectedClass = LostItem['detectedClass'];
//           final location = LostItem['location'] as GeoPoint;
//           final dateLost = LostItem['dateLost'] as Timestamp;
//           final userId = LostItem['user'];

//           final formattedDate = DateFormat('yyyy-MM-dd HH:mm').format(dateLost.toDate());
//           final latLng = LatLng(location.latitude, location.longitude);

//            return SingleChildScrollView(
//             child: Column(
//               children: [
//                 Image.network(
//                   image,
//                   height: 200,
//                   width: double.infinity,
//                   fit: BoxFit.cover,
//                 ),
//                 FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
//                   future: _getUserDocument(userId),
//                   builder: (context, userSnapshot) {
//                     if (userSnapshot.connectionState == ConnectionState.waiting) {
//                       return CircularProgressIndicator();
//                     }

//                     final user = userSnapshot.data!.data();
//                     final ownerName = user!['name'];
//                     final ownerPhone = user['phone'];

//                     return ListTile(
//                       title: Text(description),
//                       subtitle: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text('Detected Class: $detectedClass'),
//                           Text('Date Found: $formattedDate'),
//                           Text('Owner Name: $ownerName'),
//                           Text('Owner Phone: $ownerPhone'),
//                            loggedInUser.uid != userId
//                     ? ElevatedButton.icon(
//                         onPressed: () => _navigateToChat(userId),
//                         icon: Icon(Icons.chat),
//                         label: Text('Chat with Owner'),
//                       )
//                     : SizedBox.shrink(),
//                     ElevatedButton.icon(
//   onPressed: () => _navigateToSimilarItems(detectedClass, 'lost'),
//   icon: Icon(Icons.search),
//   label: Text('Show Similar Found'),
// ),

//                         ],
//                       ),
//                     );
//                   },
//                 ),
//                 SizedBox(height: 16.0),
//                 Container(
//                   height: 300,
//                   child: GoogleMap(
//                     initialCameraPosition: CameraPosition(
//                       target: latLng,
//                       zoom: 14.0,
//                     ),
//                     markers: {
//                       Marker(markerId: const MarkerId('lostItemLocation'), position: latLng),
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           );

//         },
//       ),
//     );
//   }

//       void _navigateToChat(String receiverId) {
//      Navigator.push(context, MaterialPageRoute(builder: (context) => ChatPage(receiverId: receiverId)));
//   }

//   void _navigateToSimilarItems(String detectedClass, String itemType) {
//   Navigator.push(
//     context,
//     MaterialPageRoute(
//       builder: (context) => SimilarItemsPage(
//         detectedClass: detectedClass,
//         itemType: itemType,
//       ),
//     ),
//   );
// }

// }

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:permission_handler/permission_handler.dart';

import '../chat/chatPage.dart';
import '../shared/sharedDrawer.dart';
import 'similarItemsPage.dart';

class LostItemDetailPage extends StatefulWidget {
  final String lostItemId;

  LostItemDetailPage({required this.lostItemId});

  @override
  _LostItemDetailPageState createState() => _LostItemDetailPageState();
}

class _LostItemDetailPageState extends State<LostItemDetailPage> {
  late DocumentReference<Map<String, dynamic>> _lostItemDocument;
  late Future<DocumentSnapshot<Map<String, dynamic>>> _lostItemFuture;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController _commentController = TextEditingController();
  bool _isAdmin = false;

  @override
  void initState() {
    super.initState();
    _requestLocationPermission();
    _lostItemDocument =
        FirebaseFirestore.instance.collection('lost').doc(widget.lostItemId);
    _lostItemFuture = _lostItemDocument.get();
           _checkIfUserIsAdmin();

  }

     Future<void> _checkIfUserIsAdmin() async {
    final currentUser = _auth.currentUser;
    if (currentUser != null) {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      setState(() {
        _isAdmin = userDoc.data()?['isAdmin'] ?? false;
      });
    }
  }

  Future<DocumentSnapshot<Map<String, dynamic>>> _getUserDocument(
      String userId) async {
    return await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .get();
  }

  Future<void> _requestLocationPermission() async {
    PermissionStatus status = await Permission.locationWhenInUse.request();
    if (status.isDenied) {}
  }

  @override
  Widget build(BuildContext context) {
    final loggedInUser = _auth.currentUser!;

    return Scaffold(
      appBar: AppBar(
        title: Text('Lost Item Details'),        backgroundColor: Colors.green,

      ),
      drawer: SharedDrawer(),
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: _lostItemFuture,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.data == null) {
            return Center(
              child: Text('No Lost item found.'),
            );
          }
          final lostItem = snapshot.data!.data();
          final image = lostItem!['image'];
          final description = lostItem['description'];
          final detectedClass = lostItem['detectedClass'];
          final location = lostItem['location'] as GeoPoint;
          final dateLost = lostItem['dateLost'] as Timestamp;
          final userId = lostItem['user'];

          final formattedDate =
              DateFormat('yyyy-MM-dd HH:mm').format(dateLost.toDate());
          final latLng = LatLng(location.latitude, location.longitude);

          return SingleChildScrollView(
            child: Column(
              children: [
                Image.network(
                  image,
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
                FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                  future: _getUserDocument(userId),
                  builder: (context, userSnapshot) {
                    if (userSnapshot.connectionState ==
                        ConnectionState.waiting) {
                      return CircularProgressIndicator();
                    }

                    final user = userSnapshot.data!.data();
                    final ownerName = user!['name'];
                    final ownerPhone = user['phone'];

                    return ListTile(
                      title: Text(description),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Detected Class: $detectedClass'),
                          Text('Date Found: $formattedDate'),
                          Text('Owner Name: $ownerName'),
                          Text('Owner Phone: $ownerPhone'),
                          loggedInUser.uid != userId
                              ? ElevatedButton.icon(style: ButtonStyle( 
          backgroundColor: MaterialStateProperty.all(Colors.green),  
          ),
                                  onPressed: () => _navigateToChat(userId),
                                  icon: Icon(Icons.chat),
                                  label: Text('Chat with Owner'),
                                )
                              : SizedBox.shrink(),
                          ElevatedButton.icon(style: ButtonStyle( 
          backgroundColor: MaterialStateProperty.all(Colors.green),  
          ),
                            onPressed: () =>
                                _navigateToSimilarItems(detectedClass, 'lost'),
                            icon: Icon(Icons.search),
                            label: Text('Show Similar Found'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                SizedBox(height: 16.0),
                Container(
                  height: 300,
                  child: GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: latLng,
                      zoom: 14.0,
                    ),
                    markers: {
                      Marker(
                          markerId: const MarkerId('lostItemLocation'),
                          position: latLng),
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Comments',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      TextField(
                        controller: _commentController,
                        decoration: InputDecoration(
                          hintText: 'Add a comment...',
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 12.0),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ),
                      SizedBox(height: 8.0),
                      ElevatedButton( style: ButtonStyle( 
          backgroundColor: MaterialStateProperty.all(Colors.green),  
          ),
                        onPressed: () => _addComment(),
                        child: Text('Submit Comment'),
                      ),
                      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                        stream: _lostItemDocument
                            .collection('comments')
                            .orderBy('timestamp', descending: true)
                            .snapshots(),
                        builder: (context, commentSnapshot) {
                          if (commentSnapshot.connectionState ==
                              ConnectionState.waiting) {
                            return CircularProgressIndicator();
                          }
                          if (!commentSnapshot.hasData ||
                              commentSnapshot.data!.docs.isEmpty) {
                            return Text('No comments yet.');
                          }
                          return ListView.builder(
                            shrinkWrap: true,
                            itemCount: commentSnapshot.data!.docs.length,
                            itemBuilder: (context, index) {
                              final comment =
                                  commentSnapshot.data!.docs[index].data();
                              final commenterId = comment['user'];
                              final commentText = comment['text'];
                              final timestamp =
                                  comment['timestamp'] as Timestamp;
                              final formattedTimestamp =
                                  DateFormat('yyyy-MM-dd HH:mm')
                                      .format(timestamp.toDate());
                              return FutureBuilder<
                                  DocumentSnapshot<Map<String, dynamic>>>(
                                future: _getUserDocument(commenterId),
                                builder: (context, commenterSnapshot) {
                                  if (commenterSnapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return CircularProgressIndicator();
                                  }
                                  final commenter =
                                      commenterSnapshot.data!.data();
                                  final commenterName = commenter!['name'];

                                  return ListTile(
                                    title: Text(commentText),
                                    subtitle: Text(
                                        '$commenterName - $formattedTimestamp'),
                                    trailing: loggedInUser.uid == commenterId ||
                                            loggedInUser.uid == userId
                                            ||   _isAdmin ==true

                                        ? IconButton(
                                            icon: Icon(Icons.delete),
                                            onPressed: () => _deleteComment(
                                                commentSnapshot
                                                    .data!.docs[index]),
                                          )
                                        : null,
                                  );
                                },
                              );
                            },
                          );
                        },
                      ),
                    ],
                  ),
                ),
              
              ],
            ),
          );
        },
      ),
    );
  }

  void _navigateToChat(String receiverId) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ChatPage(receiverId: receiverId)),
    );
  }

  void _navigateToSimilarItems(String detectedClass, String itemType) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SimilarItemsPage(
          detectedClass: detectedClass,
          itemType: itemType,
        ),
      ),
    );
  }

  Future<void> _addComment() async {
    if (_commentController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter a comment.')),
      );
      return;
    }
    await _lostItemDocument.collection('comments').add({
      'user': _auth.currentUser!.uid,
      'text': _commentController.text,
      'timestamp': Timestamp.now(),
    });
    _commentController.clear();
  }

  Future<void> _deleteComment(
      DocumentSnapshot<Map<String, dynamic>> commentDoc) async {
    await _lostItemDocument.collection('comments').doc(commentDoc.id).delete();
  }

}
