import 'dart:convert';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/src/material/dropdown.dart';

import '../shared/sharedDrawer.dart';

class AddItemPage extends StatefulWidget {
  @override
  _AddItemPageState createState() => _AddItemPageState();
}

class _AddItemPageState extends State<AddItemPage> {
  TextEditingController _descriptionController = TextEditingController();
  TextEditingController _detectedClassController = TextEditingController();
  bool _isFoundItem = true;

  File? _foundItemImage;
  LatLng? _currentLocation;
  final ImagePicker _picker = ImagePicker();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  bool _submitting = false;
  bool _classDetectionLoading = false;
  String? downloadUrl;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    _detectedClassController.dispose();
    super.dispose();
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Location services are disabled.'),
            content:
                Text('Please enable location services in the app settings.'),
            actions: [
              TextButton(
                onPressed: () {
                  openAppSettings();
                  Navigator.of(context).pop();
                },
                child: Text('Open Settings'),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('Cancel'),
              ),
            ],
          );
        },
      );
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {}
    }

    if (permission == LocationPermission.deniedForever) {}

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    setState(() {
      _currentLocation = LatLng(position.latitude, position.longitude);
    });
  }

  Future<void> _captureImage(ImageSource source) async {
    final pickedFile = await _picker.getImage(source: source);

    setState(() {
      _foundItemImage = File(pickedFile!.path);
    });

    if (_foundItemImage != null) {
      setState(() {
        _classDetectionLoading = true;
      });
      Map<String, String> result =
          await _uploadImageToStorage(_foundItemImage!);
      setState(() {
        _detectedClassController.text = result['detectedClass']!;
      });

      setState(() {
        downloadUrl = result['downloadUrl']!;
      });
    }
  }

  Future<Map<String, String>> _uploadImageToStorage(File image) async {
    String filePath = 'found_images/${DateTime.now()}.png';
    final storageReference = FirebaseStorage.instance.ref().child(filePath);
    final uploadTask = storageReference.putFile(image);
    await uploadTask.whenComplete(() => null);
    var downloadUrl = await storageReference.getDownloadURL();

    final response = await http.post(
      Uri.parse('https://hassalt-url.onrender.com/predict'),
      body: {'image_url': downloadUrl},
    );

    String detectedClass = '';
    if (response.statusCode == 200) {
      Map<String, dynamic> responseBody = jsonDecode(response.body);
      List<dynamic> predictions = responseBody['predictions'];
      if (predictions.isNotEmpty) {
        detectedClass = predictions[0]['class'];
        print(response);
      }
    }

    setState(() {
      _detectedClassController.text = detectedClass;
      _classDetectionLoading = false;
    });

    return {'downloadUrl': downloadUrl, 'detectedClass': detectedClass};
  }

  Future<void> _uploadFoundItem() async {
    setState(() {
      _submitting = true;
    });
    if (_foundItemImage != null) {
      Map<String, dynamic> data = {
        'description': _descriptionController.text,
        'detectedClass': _detectedClassController.text,
        'image': downloadUrl,
        'location':
            GeoPoint(_currentLocation!.latitude, _currentLocation!.longitude),
        'user': _auth.currentUser!.uid,
      };

      if (_isFoundItem) {
        data['dateFound'] = Timestamp.now();
        await _db.collection('found').add(data);
      } else {
        data['dateLost'] = Timestamp.now();
        await _db.collection('lost').add(data);
      }

      Navigator.pop(context);
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Image Missing'),
            content: Text('Please capture or select an image.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }

    setState(() {
      _submitting = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // set backgroundColor to green
      appBar: AppBar(
        title: Text(
          'Add Item',
        ),
        backgroundColor: Colors.green,
      ),
      drawer: SharedDrawer(),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Column(
                children: [
                  RadioListTile<bool>(
                    title: Text('Found Item'),
                    value: true,
                    groupValue: _isFoundItem,
                    onChanged: (bool? value) {
                      setState(() {
                        _isFoundItem = value!;
                      });
                    },
                  ),
                  RadioListTile<bool>(
                    title: Text('Lost Item'),
                    value: false,
                    groupValue: _isFoundItem,
                    onChanged: (bool? value) {
                      setState(() {
                        _isFoundItem = value!;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(height: 10),
              _buildDescriptionField(),
              SizedBox(height: 10),
              _buildDetectedClassField(),
              SizedBox(height: 10),
              _buildImageField(),
              SizedBox(height: 10),
              _buildLocationField(),
              SizedBox(height: 10),
              _buildSubmitButton(),
            ],
          ),
        ),
      ),
    );
  }

  // Widget _buildDescriptionField() {
  //   return TextField(
  //     controller: _descriptionController,
  //     decoration: InputDecoration(
  //       labelText: 'Description',
  //       border: OutlineInputBorder(),
  //     ),
  //     maxLines: 5,
  //   );
  // }

  Widget _buildDescriptionField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Description (${_isFoundItem ? "Found" : "Lost"} Item)'),
        SizedBox(height: 10),
        TextField(
          controller: _descriptionController,
          decoration: InputDecoration(
            labelText: 'Description',
            border: OutlineInputBorder(),
          ),
          maxLines: 5,
        ),
      ],
    );
  }

  Widget _buildImageField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(' Item Image'),
        SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            OutlinedButton.icon(
              onPressed: () => _captureImage(ImageSource.camera),
              icon: Icon(Icons.camera_alt),
              label: Text('Capture'),
            ),
            OutlinedButton.icon(
              onPressed: () => _captureImage(ImageSource.gallery),
              icon: Icon(Icons.photo_library),
              label: Text('Gallery'),
            ),
          ],
        ),
        SizedBox(height: 10),
        if (_foundItemImage != null)
          Stack(
            children: [
              Image.file(
                _foundItemImage!,
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ],
          ),
      ],
    );
  }

  Widget _buildLocationField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Current Location'),
        SizedBox(height: 10),
        if (_currentLocation != null)
          Text(
            'Latitude: ${_currentLocation!.latitude}, Longitude: ${_currentLocation!.longitude}',
          ),
        if (_currentLocation == null) CircularProgressIndicator(),
      ],
    );
  }

  Widget _buildSubmitButton() {
    if (_classDetectionLoading || _submitting) {
      return Center(child: CircularProgressIndicator());
    } else {
      return ElevatedButton(
        onPressed: () => _uploadFoundItem(),
        child: Text('Submit'),
      );
    }
  }

  List<String> _classOptions = [
    'KEY',
    'BACKPAGES',
    ' FLASH',
    'LAPTOP',
    'PHONE'
  ];

  Widget _buildDetectedClassField() {
    if (_classDetectionLoading) {
      return CircularProgressIndicator();
    } else {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Detected Class'),
          SizedBox(height: 10),
          if (_detectedClassController.text.isNotEmpty)
            Text(_detectedClassController.text),
          if (_detectedClassController.text.isEmpty)
            DropdownButtonFormField<String>(
              value: null,
              items: _classOptions.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  _detectedClassController.text = newValue ?? '';
                });
              },
              decoration: InputDecoration(
                labelText: 'Detected Class',
                border: OutlineInputBorder(),
              ),
            ),
        ],
      );
    }
  }
}
