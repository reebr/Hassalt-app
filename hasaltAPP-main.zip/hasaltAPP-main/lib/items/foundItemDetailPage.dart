import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hassalt_app/items/similarItemsPage.dart';
import 'package:hassalt_app/shared/sharedDrawer.dart';
 import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:permission_handler/permission_handler.dart';

import '../chat/chatPage.dart';

 


class FoundItemDetailPage extends StatefulWidget {
  final String foundItemId;

  FoundItemDetailPage({required this.foundItemId});

  @override
  _FoundItemDetailPageState createState() => _FoundItemDetailPageState();
}

class _FoundItemDetailPageState extends State<FoundItemDetailPage> {
  late DocumentReference<Map<String, dynamic>> _foundItemDocument;
  late Future<DocumentSnapshot<Map<String, dynamic>>> _foundItemFuture;
  TextEditingController _commentController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isAdmin = false;




@override
void initState() {
  super.initState();
  _requestLocationPermission();
  _foundItemDocument =
      FirebaseFirestore.instance.collection('found').doc(widget.foundItemId);
  _foundItemFuture = _foundItemDocument.get();
}
    Future<DocumentSnapshot<Map<String, dynamic>>> _getUserDocument(String userId) async {
    return await FirebaseFirestore.instance.collection('users').doc(userId).get();
  }

  Future<void> _requestLocationPermission() async {
  PermissionStatus status = await Permission.locationWhenInUse.request();
  if (status.isDenied) {
  }
}


  @override
  Widget build(BuildContext context) {
      final loggedInUser = FirebaseAuth.instance.currentUser!;

    return Scaffold(
      appBar: AppBar(
        title: Text('Found Item Details'),        backgroundColor: Colors.green,

      ),
      drawer: SharedDrawer(),
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: _foundItemFuture,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.data == null) {
            return Center(
              child: Text('No found item found.'),
            );
          }
          final foundItem = snapshot.data!.data();
          final image = foundItem!['image'];
          final description = foundItem['description'];
          final detectedClass = foundItem['detectedClass'];
          final location = foundItem['location'] as GeoPoint;
          final dateFound = foundItem['dateFound'] as Timestamp;
          final userId = foundItem['user'];
          final formattedDate = DateFormat('yyyy-MM-dd HH:mm').format(dateFound.toDate());
          final latLng = LatLng(location.latitude, location.longitude);

          return SingleChildScrollView(
            child: Column(
              children: [
                Image.network(
                  image,
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
                FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                  future: _getUserDocument(userId),
                  builder: (context, userSnapshot) {
                    if (userSnapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator();
                    }

                    final user = userSnapshot.data!.data();
                    final founderName = user!['name'];
                    final founderPhone = user['phone'];

                    return ListTile(
                      title: Text(description),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Detected Class: $detectedClass'),
                          Text('Date Found: $formattedDate'),
                          Text('Founder Name: $founderName'),
                          Text('Founder Phone: $founderPhone'),
                           loggedInUser.uid != userId
                    ? ElevatedButton.icon( style: ButtonStyle( 
          backgroundColor: MaterialStateProperty.all(Colors.green),  
          ),
                        onPressed: () => _navigateToChat(userId),
                        icon: Icon(Icons.chat),
                        label: Text('Chat with Founder'),
                      )
                    : SizedBox.shrink(),

                    ElevatedButton.icon(
                       style: ButtonStyle( 
          backgroundColor: MaterialStateProperty.all(Colors.green),  
          ),
  onPressed: () => _navigateToSimilarItems(detectedClass, 'found'),
  icon: Icon(Icons.search),
  label: Text('Show Similar Lost'),
),
                       
                        ],
                      ),
                    );
                  },
                ),
                SizedBox(height: 16.0),
                Container(
                  height: 300,
                  child: GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: latLng,
                      zoom: 14.0,
                    ),
                    markers: {
                      Marker(markerId: const MarkerId('foundItemLocation'), position: latLng),
                    },
                  ),
                ),
                 Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Comments',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      TextField(
                        controller: _commentController,
                        decoration: InputDecoration(
                          hintText: 'Add a comment...',
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 12.0),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ),
                      SizedBox(height: 8.0),
                      ElevatedButton(
                        style: ButtonStyle( 
          backgroundColor: MaterialStateProperty.all(Colors.green),  
          ),
                        onPressed: () => _addComment(),
                        child: Text('Submit Comment'),
                      ),
                      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                        stream: _foundItemDocument
                            .collection('comments')
                            .orderBy('timestamp', descending: true)
                            .snapshots(),
                        builder: (context, commentSnapshot) {
                          if (commentSnapshot.connectionState ==
                              ConnectionState.waiting) {
                            return CircularProgressIndicator();
                          }
                          if (!commentSnapshot.hasData ||
                              commentSnapshot.data!.docs.isEmpty) {
                            return Text('No comments yet.');
                          }
                          return ListView.builder(
                            shrinkWrap: true,
                            itemCount: commentSnapshot.data!.docs.length,
                            itemBuilder: (context, index) {
                              final comment =
                                  commentSnapshot.data!.docs[index].data();
                              final commenterId = comment['user'];
                              final commentText = comment['text'];
                              final timestamp =
                                  comment['timestamp'] as Timestamp;
                              final formattedTimestamp =
                                  DateFormat('yyyy-MM-dd HH:mm')
                                      .format(timestamp.toDate());
                              return FutureBuilder<
                                  DocumentSnapshot<Map<String, dynamic>>>(
                                future: _getUserDocument(commenterId),
                                builder: (context, commenterSnapshot) {
                                  if (commenterSnapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return CircularProgressIndicator();
                                  }
                                  final commenter =
                                      commenterSnapshot.data!.data();
                                  final commenterName = commenter!['name'];

                                  return ListTile(
                                    title: Text(commentText),
                                    subtitle: Text(
                                        '$commenterName - $formattedTimestamp'),
                                    trailing: loggedInUser.uid == commenterId ||
                                            loggedInUser.uid == userId || _isAdmin ==true
                                        ? IconButton(
                                            icon: Icon(Icons.delete),
                                            onPressed: () => _deleteComment(
                                                commentSnapshot
                                                    .data!.docs[index]),
                                          )
                                        : null,
                                  );
                                },
                              );
                            },
                          );
                        },
                      ),
                    ],
                  ),
                ),
              
              ],
            ),
          );
       
        },
      ),
    );
  }

    void _navigateToChat(String receiverId) {
     Navigator.push(context, MaterialPageRoute(builder: (context) => 
     ChatPage(receiverId: receiverId)));
  }

 void _navigateToSimilarItems(String detectedClass, String itemType) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => SimilarItemsPage(
        detectedClass: detectedClass,
        itemType: itemType,
      ),
    ),
  );
}

Future<void> _addComment() async {
    if (_commentController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter a comment.')),
      );
      return;
    }
    await _foundItemDocument.collection('comments').add({
      'user': _auth.currentUser!.uid,
      'text': _commentController.text,
      'timestamp': Timestamp.now(),
    });
    _commentController.clear();
  }

  Future<void> _deleteComment(
      DocumentSnapshot<Map<String, dynamic>> commentDoc) async {
    await _foundItemDocument.collection('comments').doc(commentDoc.id).delete();
  }

}
