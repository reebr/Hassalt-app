 
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class SharedAppBar extends StatefulWidget implements PreferredSizeWidget {
   final String title;
 
  const SharedAppBar({
    Key? key,
     required this.title
   }) : super(key: key);

  @override
  _SharedAppBarState createState() => _SharedAppBarState();

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}

class _SharedAppBarState extends State<SharedAppBar> {
   late String _title; 
  
    bool isLoggedIn = false;

  @override
  void initState() {
    super.initState();
    // checkAuthStatus();
    _title = widget.title;
  }

  void checkAuthStatus() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        isLoggedIn = true;
      });
    }
  }
  
 
  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.green,
      title: Text(_title),
      leading: IconButton(
        icon: Icon(Icons.menu),
        onPressed: () {
          Scaffold.of(context).openDrawer();
        },
      ),
     actions :[
      isLoggedIn
          ? IconButton(
              icon: Icon(Icons.account_circle),
              onPressed: () {
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => ProfilePage()),
                // );
              },
            )
          : SizedBox.shrink(),
    ],
    );
  }
}


