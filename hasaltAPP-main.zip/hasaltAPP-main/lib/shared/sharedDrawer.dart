import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:hassalt_app/auth/logout.dart';
import 'package:hassalt_app/chat/chatWithAdminPage.dart';
import 'package:hassalt_app/items/myItems.dart';
 
import '../chat/chatsPage.dart';
import '../items/addItems.dart';
import '../items/foundItemList.dart';
import '../items/lostItemList.dart';
 
class SharedDrawer extends StatefulWidget {
  SharedDrawer();

  @override
  State<SharedDrawer> createState() => _SharedDrawerState();
}

class _SharedDrawerState extends State<SharedDrawer> {
  void _logout(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
    } catch (e) {
      print('Error logging out: $e');
    }
  }

  bool isLoggedIn = false;

  bool isAdmin = false;

  @override
  void initState() {
    super.initState();
    checkAuthStatus();
  }

  void checkAuthStatus() async {
    User? user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      setState(() {
        isLoggedIn = true;
      });
    }
    final userDocRef =
        FirebaseFirestore.instance.collection('users').doc(user!.uid);
    final userDoc = await userDocRef.get();
    final userData = userDoc.data();
    final isAdmin = userData?['isAdmin'] ?? false;
    setState(() {
      this.isAdmin = isAdmin;
    });
  }

 

 

Stream<int> _newSendersCountStream() {
  return FirebaseFirestore.instance
      .collection('messages')
      .where('receiver', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
      .where('read', isEqualTo: false)
      .snapshots()
      .map((querySnapshot) {
    Set<String> uniqueSenders = {};
    for (var message in querySnapshot.docs) {
      uniqueSenders.add(message['sender']);
    }
    return uniqueSenders.length;
  });
}


  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    final userDocRef =
        FirebaseFirestore.instance.collection('users').doc(user.uid);
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          isLoggedIn
              ?UserAccountsDrawerHeader(
  decoration: BoxDecoration(color: Colors.green),
  accountName: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
    future: userDocRef.get(),
    builder: (context, snapshot) {
      if (snapshot.hasData) {
        final userDocData = snapshot.data!.data()!;
        return Text(userDocData['name']);
      }

      return CircularProgressIndicator();
    },
  ),
  accountEmail: null,
   
)

              : DrawerHeader(
                  child: Text('My App'),
                ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Home'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/');
            },
          ),
          ListTile(
            title: Text(
              'Items',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ),
          ListTile(
            leading: Icon(Icons.add),
            title: Text('Add New Item'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddItemPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.list),
            title: Text('Found List'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => FoundItemsPage()),
              );
            },
          ),
             ListTile(
            leading: Icon(Icons.list),
            title: Text('Lost List'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LostItemsPage()),
              );
            },
          ),
      
          
          Divider(),
             ListTile(
            leading: Icon(Icons.list),
            title: Text('My Items'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MyItemsListPage()),
              );
            },
          ),
      
          Divider(),
          isLoggedIn
              ? Column(
                  children: [
                 ListTile(
    leading: Icon(Icons.chat_bubble),
    title: Row(
      children: [
        Text('Chat'),
       StreamBuilder<int>(
  stream: _newSendersCountStream(),
  builder: (BuildContext context, AsyncSnapshot<int> snapshot) {
    if (snapshot.connectionState == ConnectionState.active) {
      return snapshot.data! > 0
          ? Padding(
              padding: EdgeInsets.only(left: 5.0),
              child: Text(
                '(${snapshot.data!})',
                style: TextStyle(color: Colors.red),
              ),
            )
          : SizedBox.shrink();
    } else {
      return SizedBox.shrink();
    }
  },
),

      ],
    ),
    onTap: () {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ChatsPage()),
      );
    },
  ),
                    !isAdmin
                        ? ListTile(
                            leading: Icon(Icons.message),
                            title: Text('Help'),
                            onTap: () async {
                         
                               Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        AdminChatPage()),
                              );
                            },
                          )
                        : SizedBox.shrink(),
                    
                  ],
                )
              : SizedBox.shrink(),

                        Divider(),

                     ListTile(
                            leading: Icon(Icons.logout),
                            title: Text('Logout'),
                            onTap: () async {
                         
                                      _logout(context);

                            },
                          )   

        ],
      ),
    );
  }
}
