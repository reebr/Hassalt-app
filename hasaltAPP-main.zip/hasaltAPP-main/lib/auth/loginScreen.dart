import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hassalt_app/auth/signupScreen.dart';
 
import '../homePage.dart';
 
class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _inputController = TextEditingController(text: 'testuser0');
  final _passwordController = TextEditingController(text: 'Test@123');


//  final _inputController = TextEditingController(text: 'testuser0');
//   final _passwordController = TextEditingController(text: 'Test@123');
  
  //  final _inputController = TextEditingController(text: 'testuser0');
  // final _passwordController = TextEditingController(text: 'Test@123');


  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;


 
  @override
  void initState() {
    super.initState();

    FirebaseAuth.instance.authStateChanges().listen((user) {
      if (user != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage()),
        );
      }
    });
  }

  void _login() async {
    setState(() {
      _isLoading = true;
    });

    try {
      UserCredential userCredential;
      String email;

      // Check if input is email, phone, or username
      if (_inputController.text.contains('@')) {
        email = _inputController.text.trim();
      } else if (_inputController.text.length == 10 &&
          int.tryParse(_inputController.text) != null) {
        final snapshot = await FirebaseFirestore.instance
            .collection('users')
            .where('phone', isEqualTo: _inputController.text.trim())
            .get();
        if (snapshot.docs.isNotEmpty) {
          email = snapshot.docs.first['email'];
        } else {
          throw FirebaseAuthException(
              code: 'user-not-found',
              message: 'User not found. Please check your input');
        }
      } else {
        final snapshot = await FirebaseFirestore.instance
            .collection('users')
            .where('username', isEqualTo: _inputController.text.trim())
            .get();
        if (snapshot.docs.isNotEmpty) {
          email = snapshot.docs.first['email'];
        } else {
          throw FirebaseAuthException(
              code: 'user-not-found',
              message: 'User not found. Please check your input');
        }
      }

      // Sign in with email and password
      userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email, password: _passwordController.text.trim());

      // Navigate to the home screen after successful login
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => HomePage()),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('User not found. Please check your input')));
      } else if (e.code == 'wrong-password') {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Wrong password. Please check your password')));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('An error occurred. Please try again')));
      }
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Text('Login'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 200,
                height: 250,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(20),
                  image: DecorationImage(
                    image: AssetImage("assets/images/logo.png"),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _inputController,
                decoration: InputDecoration(
                  labelText: 'Email, phone, or username',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email, phone, or username';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your password';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor:
                      MaterialStateProperty.all<Color>(Colors.green),
                ),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _login();
                  }
                },
                child: _isLoading
                    ? const CircularProgressIndicator()
                    : const Text('Login'),
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const SignupScreen()),
                  );
                },
                child: const Text(
                  'Don\'t have an account? Sign up here.',
                  style: TextStyle(color: Colors.green),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}