import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

 import '../homePage.dart';
import 'loginScreen.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GlobalKey<ScaffoldMessengerState> _scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  // final TextEditingController _nameController = TextEditingController();
  // final TextEditingController _emailController = TextEditingController();
  // final TextEditingController _phoneController = TextEditingController();
  // final TextEditingController _usernameController = TextEditingController();
  // final TextEditingController _passwordController = TextEditingController();
  // final TextEditingController _confirmPasswordController =
  //     TextEditingController();

  final TextEditingController _nameController =
      TextEditingController(text: 'Test Name');
  final TextEditingController _emailController =
      TextEditingController(text: 'test@kku.edu.sa');
  final TextEditingController _phoneController =
      TextEditingController(text: '0598765432');
  final TextEditingController _usernameController =
      TextEditingController(text: 'testuser');
  final TextEditingController _passwordController =
      TextEditingController(text: 'Test@123');
  final TextEditingController _confirmPasswordController =
      TextEditingController(text: 'Test@123');

  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;
  bool _nameValidated = true;
  bool _emailValidated = true;
  bool _phoneValidated = true;
  bool _usernameValidated = true;
  bool _passwordValidated = true;
  bool _confirmPasswordValidated = true;

  bool isLoading = false;
  bool _hasReadPolicies = false;

  String? _emailErrorMessage;
  String? _phoneErrorMessage;
  String? _userNameErrorMessage;
  String? _errorMessage;
  String? _emailExistsMessage;

  @override
  void initState() {
    super.initState();

    FirebaseAuth.instance.authStateChanges().listen((user) {
      if (user != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage()),
        );
      }
    });
  }

  void _showPoliciesDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Policies'),
          content: SingleChildScrollView(
            child: ListBody(
              children: const <Widget>[
                Text(
                    'Policy 1: Do not advertise or upload content or items that are inappropriate for the ratings available in the application.'),
                Text(
                    'Policy 2: Not to use any illegal means to access ads or other users data or to violate the application policy.'),
                Text(
                    'Policy 3: Not to post false, inaccurate, misleading, deceptive advertisements or comments...etc.'),
                Text(
                    'Policy 4: The application provides a service to enable the user to view a missing or existing one according to the agreed usage policy, and we do not offer any guarantees and we do not bear any responsibility in the event that the user does not adhere to the application usage policy, and we do not bear responsibility for any risk, damages, consequences or losses that fall on users.'),
                Text(
                    'Policy 5: Your use of an application means that you authorize us to save your data that you entered on the application servers, and we have the right to view and review it, and we have the right to delete the advertisement and dispose of the attached images when needed.'),
                Text(
                    'Policy 6: Your failure to comply with these conditions gives the application the full right to block your membership and prevent you from accessing the application without the need to notify you of that, and you hereby undertake to agree to use the application with the terms and conditions.'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  bool isPasswordComplex(String password) {
    final RegExp hasUppercase = RegExp(r'[A-Z]');
    final RegExp hasLowercase = RegExp(r'[a-z]');
    final RegExp hasDigit = RegExp(r'\d');
    final RegExp hasSpecialChar = RegExp(r'[!@#$%^&*(),.?":{}|<>]');

    if (!hasUppercase.hasMatch(password)) return false;
    if (!hasLowercase.hasMatch(password)) return false;
    if (!hasDigit.hasMatch(password)) return false;
    if (!hasSpecialChar.hasMatch(password)) return false;
    if (password.length < 8) return false;

    return true;
  }

  Future<bool> isPhoneExists(String phone) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('phone', isEqualTo: phone)
        .limit(1)
        .get();

    return querySnapshot.docs.isNotEmpty;
  }

  Future<bool> isUsernameExists(String username) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('username', isEqualTo: username)
        .limit(1)
        .get();

    return querySnapshot.docs.isNotEmpty;
  }

  bool isInputValid(String input) {
    return !input.contains(' ');
  }

  Future<String?> getEmailFromPhone(String phoneNumber) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('phone', isEqualTo: phoneNumber)
        .limit(1)
        .get();

    if (querySnapshot.docs.isEmpty) {
      // No user found with the given phone number
      return null;
    } else {
      // Return the email associated with the given phone number
      return querySnapshot.docs[0].get('email');
    }
  }

  Future<String?> getEmailFromUsername(String username) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('username', isEqualTo: username)
        .limit(1)
        .get();

    if (querySnapshot.docs.isEmpty) {
      // No user found with the given username
      return null;
    } else {
      // Return the email associated with the given username
      return querySnapshot.docs[0].get('email');
    }
  }

  void _validateInputs() async {
    setState(() {
      isLoading = true;
      _nameValidated = _nameController.text.isNotEmpty;
      _emailValidated = _emailController.text.isNotEmpty;
      _phoneValidated = _phoneController.text.isNotEmpty;
      _usernameValidated = _usernameController.text.isNotEmpty;
      _passwordValidated = _passwordController.text.isNotEmpty;
      _confirmPasswordValidated = _confirmPasswordController.text.isNotEmpty &&
          _passwordController.text == _confirmPasswordController.text;
    });

    if (_nameValidated &&
        (_emailValidated || _phoneValidated || _usernameValidated) &&
        _passwordValidated &&
        _confirmPasswordValidated) {
      try {
        bool isPhoneValid = true;
        bool isUsernameValid = true;

        // Validate phone
        if (_phoneValidated) {
          if (_phoneController.text.length != 10 ||
              !_phoneController.text.startsWith('05')) {
            setState(() {
              _phoneErrorMessage = 'Phone must be 10 numbers and start with 05';
            });
            print('Error Message: $_errorMessage');
            isPhoneValid = false;
          } else {
            setState(() {
              _phoneErrorMessage = null;
            });

            bool phoneExists = await isPhoneExists(_phoneController.text);

            if (phoneExists) {
              setState(() {
                isLoading = false;
                _phoneErrorMessage =
                    "The account already exists for that phone";
              });
              isPhoneValid = false;
            } else {
              _phoneErrorMessage = null;
            }
          }
        }

        // Validate username
        if (_usernameValidated) {
          bool usernameExists =
              await isUsernameExists(_usernameController.text);

          if (usernameExists) {
            setState(() {
              isLoading = false;
              _userNameErrorMessage =
                  "The account already exists for that username";
            });
            isUsernameValid = false;
          } else {
            _userNameErrorMessage = null;
          }
        }

        // Validate password complexity
        if (!isPasswordComplex(_passwordController.text)) {
          setState(() {
            _errorMessage =
                '- Password must be at least 8 characters long.\n- Must contain an uppercase letter.\n- Must contain a lowercase letter.\n- Must contain a digit.\n- Must contain a special character, @#\$.';
          });
          print('Error Message: $_errorMessage');
          return;
        } else {
          setState(() {
            _errorMessage = null;
          });
        }

        // If any of the validations fail, return
        if (!isPhoneValid || !isUsernameValid) {
          return;
        }

        // Proceed with sign up process
        UserCredential userCredential;
        String email;
        if (_emailValidated) {
          email = _emailController.text.trim().toLowerCase();
          if (!email.endsWith('@kku.edu.sa')) {
            setState(() {
              isLoading = false;
              _emailErrorMessage = "The email is not on the kku.edu.sa domain.";
            });
            return;
          } else {
            setState(() {
              _emailErrorMessage = null;
            });
          }

          userCredential = await _auth.createUserWithEmailAndPassword(
            email: email,
            password: _passwordController.text,
          );
        } else if (_phoneValidated) {
          email = (await getEmailFromPhone(_phoneController.text))!;
          userCredential = await _auth.signInWithEmailAndPassword(
            email: email,
            password: _passwordController.text,
          );
        } else {
          email = (await getEmailFromUsername(_usernameController.text))!;
          userCredential = await _auth.signInWithEmailAndPassword(
            email: email,
            password: _passwordController.text,
          );
        }
        print('User signed up: ${userCredential.user}');

        final CollectionReference usersCollection =
            FirebaseFirestore.instance.collection('users');
        await usersCollection.doc(userCredential.user!.uid).set({
          'name': _nameController.text,
          'phone':
              _phoneController.text.isNotEmpty ? _phoneController.text : '',
          'email': email,
          'username': _usernameController.text.isNotEmpty
              ? _usernameController.text
              : '',
          'isAdmin': false
        });
        Navigator.of(context)
            .pushReplacement(MaterialPageRoute(builder: (_) => HomePage()));
      } on FirebaseAuthException catch (e) {
        if (e.code == 'weak-password') {
          print('The password provided is too weak.');
          setState(() {
            _errorMessage = 'The password provided is too weak.';
          });
        } else if (e.code == 'email-already-in-use') {
          print('The account already exists for that email.');

          _emailExistsMessage = "The account already exists for that email.";
        }
      } catch (e) {
        print(e);
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

//

  void _toggleObscurePassword() {
    setState(() {
      _obscurePassword = !_obscurePassword;
    });
  }

  void _toggleObscureConfirmPassword() {
    setState(() {
      _obscureConfirmPassword = !_obscureConfirmPassword;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Text('Sign up'),
      ),
      body: Container(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                controller: _nameController,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: 'Name',
                  border: OutlineInputBorder(),
                  errorText: _nameValidated ? null : 'Name is required',
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                  errorText: _emailValidated ? null : 'Email is required',
                ),
              ),
              const SizedBox(height: 16),
              if (_emailErrorMessage != null)
                Text(
                  _emailErrorMessage!,
                  style: TextStyle(color: Colors.red),
                ),
              const SizedBox(height: 16),
              if (_emailExistsMessage != null)
                Text(
                  _emailExistsMessage!,
                  style: TextStyle(color: Colors.red),
                ),
              const SizedBox(height: 16),
              TextField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  labelText: 'Phone',
                  border: OutlineInputBorder(),
                  errorText: _phoneValidated ? null : 'Phone is required',
                ),
              ),
              const SizedBox(height: 16),
              if (_phoneErrorMessage != null)
                Text(
                  _phoneErrorMessage!,
                  style: TextStyle(color: Colors.red),
                ),
              const SizedBox(height: 16),
              TextField(
                controller: _usernameController,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: 'Username',
                  border: OutlineInputBorder(),
                  errorText: _usernameValidated ? null : 'Username is required',
                ),
              ),
              const SizedBox(height: 16),
              if (_userNameErrorMessage != null)
                Text(
                  _userNameErrorMessage!,
                  style: TextStyle(color: Colors.red),
                ),
              const SizedBox(height: 16),
              TextField(
                controller: _passwordController,
                obscureText: _obscurePassword,
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscurePassword
                          ? Icons.visibility
                          : Icons.visibility_off,
                    ),
                    onPressed: _toggleObscurePassword,
                  ),
                  errorText: _passwordValidated ? null : 'Password is required',
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _confirmPasswordController,
                obscureText: _obscureConfirmPassword,
                decoration: InputDecoration(
                  labelText: 'Confirm Password',
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscureConfirmPassword
                          ? Icons.visibility
                          : Icons.visibility_off,
                    ),
                    onPressed: _toggleObscureConfirmPassword,
                  ),
                  errorText: _confirmPasswordValidated
                      ? null
                      : 'Passwords do not match',
                ),
              ),
              const SizedBox(height: 16),
              if (_errorMessage != null)
                Text(
                  _errorMessage!,
                  style: TextStyle(color: Colors.red),
                ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Checkbox(
                    value: _hasReadPolicies,
                    onChanged: (bool? newValue) {
                      setState(() {
                        _hasReadPolicies = newValue!;
                      });
                    },
                  ),
                  Text('I have read the '),
                  TextButton(
                    onPressed: () {
                      _showPoliciesDialog(context);
                    },
                    child: Text(
                      'policies',
                      style: TextStyle(decoration: TextDecoration.underline),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ButtonStyle(
                    backgroundColor:
                        MaterialStateProperty.all<Color>(Colors.green)),
                onPressed: isLoading
                    ? null
                    : () => setState(() => {
                          if (!_hasReadPolicies)
                            {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content: Text(
                                        'Please read and accept the policies.')),
                              )
                            }
                          else
                            {_validateInputs()}
                        }),
                child:
                    isLoading ? CircularProgressIndicator() : Text('Sign up'),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text("Already have an account?"),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (context) => LoginScreen()),
                      );
                    },
                    child: const Text(
                      "Log in",
                      style: TextStyle(color: Colors.green),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}