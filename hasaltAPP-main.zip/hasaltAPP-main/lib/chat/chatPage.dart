import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import '../shared/sharedDrawer.dart';

class ChatPage extends StatefulWidget {
  final String receiverId;

  ChatPage({required this.receiverId});

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  TextEditingController _messageController = TextEditingController();
  @override
  void initState() {
    super.initState();
    initializeDateFormatting();
    _markMessagesAsRead();
  }

  void _markMessagesAsRead() async {
    final messagesQuery = await FirebaseFirestore.instance
        .collection('messages')
        .where('receiver', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
        .where('sender', isEqualTo: widget.receiverId)
        .where('read', isEqualTo: false)
        .get();

    for (var message in messagesQuery.docs) {
      FirebaseFirestore.instance
          .collection('messages')
          .doc(message.id)
          .update({'read': true});
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat'),
        backgroundColor: Colors.green,
      ),
            drawer: SharedDrawer(),

      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection('messages')
                  .orderBy('timestamp', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return Center(child: CircularProgressIndicator());
                }

                // Filter messages for the current conversation
                List<DocumentSnapshot<Map<String, dynamic>>> messages = snapshot.data!.docs.where((message) {
                  return (message['sender'] == widget.receiverId && message['receiver'] == FirebaseAuth.instance.currentUser!.uid) ||
                      (message['receiver'] == widget.receiverId && message['sender'] == FirebaseAuth.instance.currentUser!.uid);
                }).toList();

                 
                
              //...
return
ListView.builder(
  reverse: true,
  itemCount: messages.length,
  itemBuilder: (context, index) {
    final messageSenderId = messages[index]['sender'];
    final isCurrentUser = messageSenderId == FirebaseAuth.instance.currentUser!.uid;
    final messageTimestamp = messages[index]['timestamp'].toDate();
    final timeAgo = timeago(messageTimestamp);
    
    return ListTile(
      title: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: FirebaseFirestore.instance.collection('users').doc(messageSenderId).get(),
        builder: (BuildContext context, AsyncSnapshot<DocumentSnapshot<Map<String, dynamic>>> snapshot) {
          String senderName;
          if (snapshot.hasData) {
            senderName = isCurrentUser ? 'You' : snapshot.data!.data()!['name'];
          } else {
            senderName = isCurrentUser ? 'You' : 'Loading...';
          }
          return RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: '$senderName said: ',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                TextSpan(
                  text: messages[index]['text'],
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
          );
        },
      ),
      subtitle: Text(timeAgo),
    );
  },
);

              },
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(hintText: 'Type a message'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,      
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


    void _sendMessage() async {
    if (_messageController.text.trim().isNotEmpty) {
      FirebaseFirestore.instance.collection('messages').add({
        'text': _messageController.text.trim(),
        'sender': FirebaseAuth.instance.currentUser!.uid,
        'receiver': widget.receiverId,
        'timestamp': Timestamp.now(),
        'read':false
      });
      _messageController.clear();
    }
  }


  String timeago(DateTime d) {
  Duration diff = DateTime.now().difference(d);
  if (diff.inDays > 365) {
    return '${(diff.inDays / 365).floor()} years ago';
  } else if (diff.inDays > 30) {
    return '${(diff.inDays / 30).floor()} months ago';
  } else if (diff.inDays > 0) {
    return '${diff.inDays} days ago';
  } else if (diff.inHours > 0) {
    return '${diff.inHours} hours ago';
  } else if (diff.inMinutes > 0) {
    return '${diff.inMinutes} minutes ago';
  } else {
    return 'Just now';
  }
}



}
