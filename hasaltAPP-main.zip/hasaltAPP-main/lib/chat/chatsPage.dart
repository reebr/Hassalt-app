import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../shared/sharedDrawer.dart';
import 'chatPage.dart';

class ChatsPage extends StatefulWidget {
  @override
  _ChatsPageState createState() => _ChatsPageState();
}

class _ChatsPageState extends State<ChatsPage> {
  late Future<List<QueryDocumentSnapshot<Map<String, dynamic>>>> _chatsFuture;

  @override
  void initState() {
    super.initState();
    _chatsFuture = _fetchConversations();
  }
Future<List<QueryDocumentSnapshot<Map<String, dynamic>>>> _fetchConversations() async {
  final currentUser = FirebaseAuth.instance.currentUser!.uid;
  final messagesQuerySnapshot = await FirebaseFirestore.instance
      .collection('messages')
      .where('sender', isEqualTo: currentUser)
      .orderBy('timestamp', descending: true)
      .get();

  final receivedMessagesQuerySnapshot = await FirebaseFirestore.instance
      .collection('messages')
      .where('receiver', isEqualTo: currentUser)
      .orderBy('timestamp', descending: true)
      .get();

  final messages = messagesQuerySnapshot.docs + receivedMessagesQuerySnapshot.docs;
  final uniqueChats = <String, QueryDocumentSnapshot>{};
  for (var message in messages) {
    final sender = message['sender'];
    final receiver = message['receiver'];
    final chatPartner = sender == currentUser ? receiver : sender;
    if (!uniqueChats.containsKey(chatPartner)) {
      uniqueChats[chatPartner] = message;
    }
  }
  return uniqueChats.values.toList().cast<QueryDocumentSnapshot<Map<String, dynamic>>>();
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chats'),        backgroundColor: Colors.green,

      ),
            drawer: SharedDrawer(),

      body: FutureBuilder<List<QueryDocumentSnapshot<Map<String, dynamic>>>>(
        future: _chatsFuture,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          final chats = snapshot.data!;
          return ListView.builder(
            itemCount: chats.length,
            itemBuilder: (context, index) {
              final chat = chats[index].data();
              final lastMessage = chat['text'];
              final chatPartnerId = chat['sender'] == FirebaseAuth.instance.currentUser!.uid
                  ? chat['receiver']
                  : chat['sender'];

              return ListTile(
                title: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                  future: FirebaseFirestore.instance.collection('users').doc(chatPartnerId).get(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      final chatPartnerName = snapshot.data!.data()!['name'];
                      return Text(chatPartnerName);
                    }
                    return Text('Loading...');
                  },
                ),
                subtitle: Text(lastMessage),
                onTap: () {
                   Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChatPage(  receiverId: chatPartnerId,),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
