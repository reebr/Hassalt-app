import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hassalt_app/chat/chatPage.dart';

import '../shared/sharedDrawer.dart';
// import 'package:your_app/chat_page.dart'; // Import your chat page here

class AdminChatPage extends StatefulWidget {
  @override
  _AdminChatPageState createState() => _AdminChatPageState();
}

class _AdminChatPageState extends State<AdminChatPage> {
  Stream<QuerySnapshot> _fetchAdminUsers() {
    return FirebaseFirestore.instance
        .collection('users')
        .where('isAdmin', isEqualTo: true)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Choose an Admin to Chat')),
            drawer: SharedDrawer(),        backgroundColor: Colors.green,


      body: StreamBuilder<QuerySnapshot>(
        stream: _fetchAdminUsers(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              final adminUser = snapshot.data!.docs[index];
              return ListTile(
                title: Text(adminUser['name']),
                onTap: () {
                    Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChatPage(
                        receiverId: adminUser.id
                       ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
